#include "grasp.h"
using namespace std;
using namespace cv;


Grasp::Grasp(){}

Grasp::Grasp(const cv::Mat & binImg)
{
  rows =  binImg.rows;
  cols = binImg.cols;
  /* Besoin de vérifier que l'image est de forme correcte */


  //créer des variables pour contenir le contour et la hiérarchie
  vector<Vec4i> hierarchy;
  vector<vector<Point> > contours;

  //trouver les contours de l'image binaire d'entrée
  findContours(binImg,contours,hierarchy,RETR_TREE,CHAIN_APPROX_SIMPLE,Point(0,0));

  //saisissez le plus grand contour
  double area = 0; //mettre à jour la zone pour trouver la plus grande zone
  vector<Point> *tracker; //définir le plus grand contour sur ce pointeur
  vector<vector<Point>>::iterator cntItr = contours.begin();

  //itérer à travers tous les contours <- pouvons-nous simplement choisir le haut de la hiérarchie
  for(;cntItr != contours.end();cntItr++){
    double tmpArea = contourArea(*cntItr);
    if(tmpArea > area)
    {
      tracker = &(*cntItr);
      area = tmpArea;
    }
  }

  //polygoniser le plus grand contour
  approxPolyDP(*tracker,polygon,epsilon,true);

  //calculer le périmètre du contour
  perimeter = arcLength(polygon,true);

  //trouver le centre de gravité du contour
  findCentroid();

}

void Grasp::generateGrasp()
{
  // nous voulons d'abord déterminer l'espace h-k
  // déterminer les régions d'incertitude antipodale.
  vector<vector<float>> antipodal_regions;
  findAntipodalRegions(antipodal_regions);
}

// La fonction affiche le contour après avoir été simplifié en polygones
void Grasp::displayPolygon()
{
  Mat result = Mat::zeros(rows,cols,CV_8UC1);
  vector<vector<Point>> tmpCont;
  tmpCont.push_back(polygon);
  drawContours(result,tmpCont,0,Scalar(255),1,LINE_4,noArray(),8,Point());
  namedWindow("polygon",WINDOW_NORMAL);
  imshow("polygon",result);
}

void Grasp::displayDiscretizedPolygon()
{
  // S'il n'y a pas assez de points discrets, lancez une erreur
  if (Poly_D.size() == 0)
  {
    throw "Polygon was not discretized or descretization failed";
  }
  // Faire une image vierge
  Mat discreteImg = Mat::zeros(rows,cols,CV_8UC1);

  // Itérer à travers le polygone et tracer ses points
  for(int cnt = 0; cnt < Poly_D.size(); cnt++)
  {
      discreteImg.at<char>(Poly_D[cnt].y,Poly_D[cnt].x) = 255;
  }
  namedWindow("discrete polygon",WINDOW_NORMAL);
  imshow("discrete polygon",discreteImg);
}

// La fonction trouve une version discrète du polygone.
// La valeur de la résolution doit être une valeur comprise entre 0 et 1 exclusif,
// représentant la fraction de pixels conservés.
void Grasp::discretizePolygon(double resolution)
{
  if (resolution >= 1 || resolution <= 0)
  {
    throw "incorrect resolution value, must be 0 < resolution < 1";
  }

    // Passez par chaque point du contour
  int cnt = 0;
  for (; cnt != polygon.size(); cnt++)
  {
    int x2, y2, x1 , y1;
    if (cnt == 0)
    {
      x2 = polygon[cnt].x;
      y2 = polygon[cnt].y;
      x1 = polygon[polygon.size() - 1].x;
      y1 = polygon[polygon.size() - 1].y;
    }
    else
    {
    // Trouver la distance entre les points actuels et précédents
      x2 = polygon[cnt].x;
      y2 = polygon[cnt].y;
      x1 = polygon[cnt-1].x;
      y1 = polygon[cnt-1].y;
    }
    double distance = sqrt(pow(x2 - x1,2) + pow(y2 - y1,2));

    // Détermine le nombre de points à générer
    // Soustraire un pour tenir compte du point de départ
    int numPoints = round(distance * resolution) - 1;

    // Créez une ligne entre les deux points
    Line tmpLine = Line(Point(x1, y1),Point(x2, y2));

    // Add the first point to the descritized shape
    Point2d startPoint = Point(x1, y1);
    Poly_D.push_back(startPoint);
    // stocke le point "normal" comme coin
    // le vecteur unitaire ne peut pas avoir une magnitude supérieure à 1
    // donc le ci-dessous fonctionne
    Point2d corner = Point(2,2);
    normals_D.push_back(corner);
    // Générer numPoints nombre de points entre les deux extrémités
    for (int cp = 1; cp <= numPoints; cp++)
    {
    // Calculer le point suivant
      Point2d nxtPoint = startPoint + (tmpLine.uVec * cp / resolution);

      nxtPoint.x = round(nxtPoint.x);
      nxtPoint.y = round(nxtPoint.y);
    // Ajouter le point suivant à la liste des polygones discrétisés
      Poly_D.push_back(nxtPoint);

    // Ajouter la normale au vecteur
      normals_D.push_back(tmpLine.getPerpendicular());
    }
  }
}

void Grasp::findCentroid()
{
  // obtenir des moments de polygone
  Moments mmnts = moments(polygon);

  // calculer le centre de gravité du polygone
  int cx = int(mmnts.m10/mmnts.m00);
  int cy = int(mmnts.m01/mmnts.m00);

  // assigner cx et cy au tableau
  centroid.x = cx;
  centroid.y = cy;
}

void Grasp::findAntipodalRegions(vector<vector<float>> & regions)
{
  for(int itr = 0; itr < Poly_D.size(); itr++)
  {
    // points évalués dans l'itération actuelle
    Point * pt1;
    Point * pt2;
    // normales respectives des points
    Point2d op_norm_1;
    Point2d op_norm_2;
    // cela stockera la plus petite plage trouvée
    float minDist = 2*3.1415;

    // assurez-vous d'évaluer le premier et le dernier index du tableau ensemble
    if (itr == Poly_D.size()-1)
    {
    // définir des points
      pt1 = &Poly_D[itr];
      pt2 = &Poly_D[0];

    // définir des normales
      op_norm_1 = Point2d(normals_D[itr]);
      op_norm_2 = Point2d(normals_D[0]);
    }
    else
    {
      pt1 = &Poly_D[itr];
      pt2 = &Poly_D[itr+1];

      op_norm_1 = Point2d(normals_D[itr]);
      op_norm_2 = Point2d(normals_D[itr+1]);
    }

    // pour l'instant, nous allons sauter les sommets
    if (op_norm_1.x == 2 || op_norm_2.x == 2)
    {
      continue;
    }
    //////////////////////////////

    // prendre l'inverse des normales
    op_norm_1 = -1 * op_norm_1;
    op_norm_2 = -1 * op_norm_2;

    // Future Edit: ce qui suit pourrait être implémentable dans un
    // meilleure façon. Besoin de considérer les possibilités

    // itérer à travers chaque combinaison de paires de vecteurs
    for (int vtr = 0; vtr < Poly_D.size(); vtr++)
    {
      for (int wtr = 0; wtr < Poly_D.size(); wtr++)
      {
        //
        if (vtr == wtr || vtr == itr || wtr == itr) continue;
    // obtenir les vecteurs normaux
        Point2d * norm_v = &normals_D[vtr];
        Point2d * norm_w = &normals_D[wtr];


      }
    }

  }
}
