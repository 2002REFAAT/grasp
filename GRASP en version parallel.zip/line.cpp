#include "line.h"
using namespace std;
using namespace cv;

Line::Line()
{
  corner = true;
}

Line::Line(Point2d pos1, Point2d pos2)
{
  startPoint.x = pos1.x;
  startPoint.y = pos1.y;

  mag = sqrt(pow(pos1.x - pos2.x, 2) + pow(pos1.y - pos2.y, 2));

  uVec.x = (pos2.x - pos1.x) / mag;
  uVec.y = (pos2.y - pos1.y) / mag;

  corner = false;

}

Point2d Line::getPerpendicular()
{
  Point2d perpUVect;
  perpUVect.x = uVec.y;
  perpUVect.y = uVec.x * (-1);

  return perpUVect;
}

double Line::getAngleWith(double l1[2])
{
  return cos(l1[0] * uVec.x + l1[1] * uVec.y);
}
